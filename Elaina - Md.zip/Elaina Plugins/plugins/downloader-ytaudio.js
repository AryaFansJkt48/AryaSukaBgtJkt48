import ytdl from '@distube/ytdl-core'
import { toAudio } from '../lib/converter.js'
import fs from 'fs'
import sharp from "sharp"

let regex = /https:\/\/(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]+(\?[\w=&-]+)?|https:\/\/(?:www\.)?youtube\.com\/(?:shorts|watch)\/[a-zA-Z0-9_-]+(?:\?si=[a-zA-Z0-9_-]+)?/i

let handler = async (m, { conn, args, command, usedPrefix }) => {
    try {
        if (!conn.youtube) conn.youtube = {}
        if (!args[0]) return m.reply(`Masukan Link Youtube!\n\nContoh :\n${usedPrefix + command} https://youtu.be/Wky7Gz_5CZs`)
        let isLink = args[0].match(regex)
        if (!isLink) return m.reply("Itu bukan link youtube!")
        if (typeof conn.youtube[m.sender] !== "undefined") return m.reply("Kamu masih download!")
        await global.loading(m, conn)
        conn.youtube[m.sender] = "loading"
        let agent = ytdl.createAgent(cookies)
        let { videoDetails } = await ytdl.getInfo(args[0], { agent })
        let caption = `
*Youtube Audio Downloader*

❏ Title : ${videoDetails.title}
❏ View : ${toRupiah(videoDetails.viewCount)}
❏ Category : ${videoDetails.category}
❏ Author : ${videoDetails.ownerChannelName}
`.trim()
        let thumbnail = (await conn.getFile(videoDetails.thumbnails.reverse()[0].url)).data
        let filename = "./.npm/" + Date.now() + ".jpg"
        await sharp(thumbnail).toFormat('jpeg').toFile(filename)
        
        let chat = await conn.adReply(m.chat, caption, videoDetails.title, null, filename, args[0], m)
        let audio = await getAudio(args[0])
        let sizeMB = audio.byteLength / (1024 * 1024)
        if (sizeMB > 50000) return m.reply("Size audio terlalu besar!")
        await conn.sendFile(m.chat, audio.data, null, null, chat, false, { mimetype: "audio/mpeg" })
    } finally {
        await global.loading(m, conn, true)
        delete conn.youtube[m.sender]
    }
}
handler.help = ['ytmp3']
handler.tags = ['downloader']
handler.command = /^(yt(mp3|audio)|youtube(mp3|audio))$/i
handler.limit = true
export default handler

async function getAudio(url) {
    let randomName = new Date() * 1 + '.mp4'
    let agent = ytdl.createAgent(cookies)
    let stream = ytdl(url, {
        filter: (info) => (info.itag == 22 || info.itag == 18),
        agent
    }).pipe(fs.createWriteStream(`./.npm/${randomName}`))
    await new Promise((resolve, reject) => {
        stream.on('error', reject)
        stream.on('finish', resolve)
    })
    let audio = await toAudio(fs.readFileSync("./.npm/" + randomName), 'mp4')
    return audio
}

let getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

let toRupiah = number => parseInt(number).toLocaleString().replace(/,/g, ".")

const cookies = [
  { name: "__Secure-1PAPISID", value: "wm7OaqNLDEmXFkCc/ADwTZh3MDpC2xCawm" },
  { name: "__Secure-1PSID", value: "g.a000pAixZdXoXazwXScj8SAOmWe0jK52R7QqdrFt1tSljwyCxMREug9mzjjDEr8DFd-Yl5LG6AACgYKAQESARQSFQHGX2Mi1PJqgwVQBIOI23wFj1wj8hoVAUF8yKrBE8ie9heAbCv6jIqJjdus0076" },
  { name: "__Secure-1PSIDCC", value: "AKEyXzVvDEZnj9JgQ0pfB87WuU3GVeTH5lByH_paz-cfQchnymkF-wO_XuRgADJ-E11N7pefcg" },
  { name: "__Secure-1PSIDTS", value: "sidts-CjEBUFGoh-DcbhqMaSIUQEOJxeOfHZKNslrrWV6jAFea4tWWvU-zT2hBMR40YnDh4UXsEAA" },
  { name: "__Secure-3PAPISID", value: "wm7OaqNLDEmXFkCc/ADwTZh3MDpC2xCawm" },
  { name: "__Secure-3PSID", value: "g.a000pAixZdXoXazwXScj8SAOmWe0jK52R7QqdrFt1tSljwyCxMREldQ7UHEOC2mLSlxBS9Sk5QACgYKAb0SARQSFQHGX2Mi0TdnNgZ9XQvu9HkjN6-xWRoVAUF8yKqg4_vvUZD0MQ30lssTHxxO0076" },
  { name: "__Secure-3PSIDCC", value: "AKEyXzWSzs7e4xLUKjH3LSfvq8wwlssn3k7T7DaK_bK1WG49AXSlGBPvNn1R1rXSdg_S0SMe" },
  { name: "__Secure-3PSIDTS", value: "sidts-CjEBUFGoh-DcbhqMaSIUQEOJxeOfHZKNslrrWV6jAFea4tWWvU-zT2hBMR40YnDh4UXsEAA" },
  { name: "APISID", value: "CEMXz078_Ib8Uqjw/A8jNg4d6SSbsLwYSC" },
  { name: "HSID", value: "AY8Xv7Rvbxj6vvM5Y" },
  { name: "LOGIN_INFO", value: "AFmmF2swRgIhAJhYxg8uQRXTvG940bFkuGm59ksgnFCP0JfW8X1enoplAiEAo__WahbPl8UyGJ3aC3YWww17YLEXporIHaAkOms6V4I:QUQ3MjNmenBmWUZfZEtDUDUyZGRaXzNlZ0Z3YWp2R0hna08waEgxX01SbGJUc0Q1N25xR2Q3NTRwbWRQV0hPeDNWcEh1ekN4QU9IS1UxQVFHZG5rSkhtb1hPZkQxVU1YaHQ4aV95MkxReDFEamxvekxZVXJvQ183X2Q4cGpYOS1nUHQ5YTA0Z2NCT3JkVHliSmJxRUIyMFlqOF9wUDRFbTFn" },
  { name: "PREF", value: "f6=40000000&tz=Asia.Jakarta" },
  { name: "SAPISID", value: "wm7OaqNLDEmXFkCc/ADwTZh3MDpC2xCawm" },
  { name: "SID", value: "g.a000pAixZdXoXazwXScj8SAOmWe0jK52R7QqdrFt1tSljwyCxMRE1U98t2BRaJVPVfbmB89y-wACgYKAeASARQSFQHGX2Milq2JmiMqsBLlW9WgEPCKZBoVAUF8yKqc6D4iXkDcKD5ZXybuOfMX0076" },
  { name: "SIDCC", value: "AKEyXzUX-UQDDK87VOgPIWm3dZn8xbXNDEtTpuJDeSI_j23K5BMLN7ij6gonWnEHJBrJY3U7" },
  { name: "SSID", value: "A46x8_4Parsm84iq_" }
]