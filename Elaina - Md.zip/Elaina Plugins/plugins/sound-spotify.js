import { SpotifyAPI } from '../lib/spotify.js'
import fs from "fs"
import axios from "axios"

let handler = async (m, { conn, text, usedPrefix, command, isPrems }) => {
    try {
        if (!text) return m.reply(`Masukan judul lagu atau link spotify! \n\nContoh : \n${usedPrefix + command} rewrite the star \n${usedPrefix + command} https://open.spotify.com/track/65fpYBrI8o2cfrwf2US4gq`)
        await global.loading(m, conn)
        if (/http(s)?:\/\/open.spotify.com\/track\/[-a-zA-Z0-9]/i.test(text)) {
            let input = text.replace('https://', '').split('/')[2]
            let spotify = await SpotifyAPI()
            let { popularity, id, duration_ms, name, artists, album } = await spotify.getTracks(input)
            let caption = `
_*${name}*_

Artist : ${artists[0].name}
Duration : ${convertMsToMinSec(duration_ms)}
Popularity : ${popularity}
Id : ${id}

Album Info :
• Name : ${album.name}
• Release : ${album.release_date}
• Id : ${album.id}
`.trim()
            let chat = await conn.sendFile(m.chat, 'https://external-content.duckduckgo.com/iu/?u=' + album.images[0].url, false, caption, m, false, false, { smlcap: true, except: [id, album.id] })
            let audio = await spotifyDL(text)
            await conn.sendFile(m.chat, audio.music, null, null, chat, false, { mimetype: "audio/mpeg" })
        } else {
            let spotify = await SpotifyAPI()
            let { tracks } = await spotify.trackSearch(text)
            let hwaifu = JSON.parse(fs.readFileSync('./assets/games/hwaifu.json', 'utf-8'))
            let list = tracks.items.map((v, i) => {
                return [`${usedPrefix + command} ${v.external_urls.spotify}`, (i + 1).toString(), `${v.name} \nArtist By ${v.artists[0].name}`]
            })
            await conn.textList(m.chat, `Terdapat *${tracks.items.length} Hasil* \nSilahkan pilih lagu yang kamu mau!`, false, list, m, {
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: false,
                        mediaType: 1,
                        title: tracks.items[0].name,
                        body: `Artist By ${tracks.items[0].artists[0].name}`,
                        thumbnail: (await conn.getFile("https://external-content.duckduckgo.com/iu/?u=" + tracks.items[0].album.images[0].url)).data,
                        renderLargerThumbnail: true,
                        mediaUrl: tracks.items[0].external_urls.spotify,
                        sourceUrl: tracks.items[0].external_urls.spotify
                    }
                }
            })
        }
    } finally {
        await global.loading(m, conn, true)
    }
}
handler.help = ['spotify']
handler.tags = ['sound']
handler.command = /^spotify$/i
handler.onlyprem = true
handler.limit = true
export default handler

function convertMsToMinSec(ms) {
    let seconds = Math.floor(ms / 1000)
    let minutes = Math.floor(seconds / 60)
    let remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds}`
}


/**
* Scraped By Kaviaann
* Protected By MIT LICENSE
* Whoever caught removing wm will be sued
* @description Any Request? Contact me : vielynian@gmail.com
* @author Kaviaann 2024
* @copyright https://whatsapp.com/channel/0029Vac0YNgAjPXNKPXCvE2e
*/
function spotifyDL(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const match = url.match(/(track|album|playlist)\/([\w\d]+)/i)
            const type = match?.[1]
            const id = match?.[2]

            if (!id) return reject("Failed To Get Id! Enter Valid Spotify URL!")

            const headers = {
                Origin: "https://spotifydown.com",
                Referer: "https://spotifydown.com/",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0 Win64 x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            }

            if (type === "track") {
                const data = await axios.get(`https://api.spotifydown.com/download/${id}`, { headers }).then(res => res.data)
                if (!data.success) return reject("Fail Fetching")
                
                const metadata = { ...data.metadata, type, music: data.link, link: url }
                delete metadata.cache
                delete metadata.success
                delete metadata.isrc

                resolve(metadata)
            } else {
                const metadata = await axios.get(`https://api.spotifydown.com/metadata/${type}/${id}`, { headers }).then(res => res.data)
                if (!metadata.success) return reject(`Failed To Get ${type} Metadata`)

                const trackList = await axios.get(`https://api.spotifydown.com/trackList/${type}/${id}`, { headers }).then(res => res.data)
                if (!trackList.success) return reject(`Failed To Get ${type} Tracklist`)

                const tracks = trackList.trackList.map(v => ({
                    id: v.id,
                    title: v.title,
                    artists: v.artists,
                    cover: v.cover || "",
                    link: `https://open.spotify.com/track/${v.id}`
                }))

                resolve({ type, link: url, ...metadata, track: tracks })
            }
        } catch (error) {
            reject(error)
        }
    })
}